def myfunction():
    return "Module1: This is myfunction in the " + __name__ + " module."

if __name__ == "__main__": 
    print ("Module1 is now the main.")
